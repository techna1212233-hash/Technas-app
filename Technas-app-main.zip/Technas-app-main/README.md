# Technas-app
This app make to earn money to mining coin and wait for listing our listing is very high 
